document.addEventListener('DOMContentLoaded', () => {
    // عناصر الواجهة
    const startQuizBtn = document.getElementById('start-quiz-btn');
    const welcomeScreen = document.getElementById('welcome-screen');
    const quizScreen = document.getElementById('quiz-screen');
    const nextButton = document.getElementById('next-btn');
    const checkAnswerBtn = document.getElementById('check-answer-btn');
    const restartButton = document.getElementById('restart-btn');
    const questionElement = document.getElementById('question');
    const answerButtonsElement = document.getElementById('answer-buttons');
    const resultElement = document.getElementById('result');
    const scoreElement = document.getElementById('score');
    const totalElement = document.getElementById('total');
    const timeElement = document.getElementById('time');
    const helpBtn = document.getElementById('help-btn');
    const callFriendBtn = document.getElementById('call-friend-btn');
    
    // متغيرات التطبيق
    let shuffledQuestions, currentQuestionIndex, score, timer;
    let helpUsed = false;
    let callFriendUsed = false;
    const questionTime = 20; // 20 ثانية لكل سؤال
    
    // الأسئلة الجديدة
    const questions = [
        { question: "من هو نصر الدين النصراوي 👊", options: ["الكوز", "ثوري", "لا إرادي"], answer: "ثوري" },
        { question: "عبد الحفيظ من الناس اشتهرت في ميديا لأنه كان يقدم:", options: ["الأفكار تتطرف", "الأفكار تحفيز ورفع المعنوي", "الأفكار بخلي الواحد يسلك طريق غلط"], answer: "الأفكار تحفيز ورفع المعنوي" },
        { question: "\"بالعلم والإبداع نستطيع أن نبني السودان يرتقي بين العوالم\" من القائل؟", options: ["د. عبد الله حمدوك", "مهندس شريف", "شاعر الفيتوري"], answer: "مهندس شريف" },
        { question: "نصراوي أحد الأفراد الثورجي، ما هو تصنيفه؟", options: ["كوز متخفي", "ثوري", "مؤثر بدون وعي"], answer: "ثوري" },
        { question: "عبدالرسول يمثل صوت التغيير الثوري، كيف ترى أثره في تحريك الضمير الجمعي؟", options: ["صدى لآراء الآخرين", "يُشعل وعي الجماهير", "دعوة للفوضى"], answer: "يُشعل وعي الجماهير" },
        { question: "كيف تؤثر أفكار عبدالرسول الثورية على مستقبل الأجيال؟", options: ["تترك أثرًا سلبيًا", "تبني وعيًا جديدًا", "لا تؤثر كثيرًا"], answer: "تبني وعيًا جديدًا" },
        { question: "هل يمكن أن تنجح الثورة بدون قادة مثل عبدالرسول؟", options: ["نعم، الشعوب تقود نفسها", "لا، القيادة مهمة", "ربما، لكنها تسرّع المسار"], answer: "ربما، لكنها تسرّع المسار" },
        { question: "ما الذي يجعل الشباب يفقدون الأمل في السودان؟", options: ["غياب القدوة", "قمع الإبداع", "الواقع الاقتصادي"], answer: "الواقع الاقتصادي" },
        { question: "متى تتحول الثورة إلى مشروع وطني؟", options: ["عند وجود مطالب واضحة", "عندما يتولى الجيش السلطة", "بعد سنوات من التظاهر"], answer: "عند وجود مطالب واضحة" },
        { question: "نقطة ضعف الناشطين في السوشيال ميديا؟", options: ["الظهور دون تأثير", "عدم فهم السياسة", "إهمال الجمهور"], answer: "الظهور دون تأثير" },
        { question: "لماذا يهاجر كثير من المبدعين؟", options: ["لا يحبون بلدهم", "بحثًا عن بيئة داعمة", "لأن الشهرة بالخارج أسهل"], answer: "بحثًا عن بيئة داعمة" },
        { question: "صفة القائد الثوري الحقيقي؟", options: ["يصرخ كثيرًا", "يستعرض قوته", "يقدّم رؤية واقعية"], answer: "يقدّم رؤية واقعية" },
        { question: "ما الذي يريده عبدالرسول؟", options: ["تغيير الأشخاص فقط", "عدالة وكرامة", "فرض رأي واحد"], answer: "عدالة وكرامة" },
        { question: "لماذا تفشل مبادرات مجتمعية كثيرة؟", options: ["الناس ما عايزة تتغير", "ليست مؤسّسة بوضوح", "ضد الدين"], answer: "ليست مؤسّسة بوضوح" },
        { question: "ما هو النجاح الحقيقي؟", options: ["شهرة ومال", "تأثير إيجابي", "متابعين كُثر"], answer: "تأثير إيجابي" },
        { question: "ما الذي يجعل الكلام الجميل غير مفيد؟", options: ["مكرر", "بلا تطبيق", "ليس عاطفيًا"], answer: "بلا تطبيق" },
        { question: "ما هو أخطر شيء على الوعي العام؟", options: ["كثرة الآراء", "الأخبار الكاذبة", "النقاش المفتوح"], answer: "الأخبار الكاذبة" },
        { question: "لماذا نرفض النقد؟", options: ["ثقة زائدة", "نقص وعي", "لأنه يوجع الحقيقة"], answer: "لأنه يوجع الحقيقة" },
        { question: "لماذا نخاف من طرح الأسئلة؟", options: ["لا نعرف", "محرمة", "تكشف الحقيقة"], answer: "تكشف الحقيقة" },
        { question: "من أسباب ضعف التعليم؟", options: ["قلة موارد", "عدم تأهيل المعلمين", "الطلاب كسالى"], answer: "عدم تأهيل المعلمين" },
        { question: "متى يشعر الإنسان بقيمته؟", options: ["عندما يُحترم", "عندما يتعلم", "عندما يُصفق له الناس"], answer: "عندما يُحترم" },
        { question: "ما الذي يصنع التغيير الحقيقي؟", options: ["خطاب قوي", "شباب واعٍ", "دعم خارجي"], answer: "شباب واعٍ" },
        { question: "كيف نعرف أن الثورة انحرفت؟", options: ["عندما تعود للوراء", "عندما تُقمع الأصوات", "عندما يسود خطاب الكراهية"], answer: "عندما يسود خطاب الكراهية" },
        { question: "ما فائدة القراءة؟", options: ["قتل الوقت", "توسيع الأفق", "تكوين صداقات"], answer: "توسيع الأفق" },
        { question: "من أقوى سلاح بيد الشباب؟", options: ["المال", "السوشيال ميديا", "الوعي"], answer: "الوعي" },
        { question: "هل الإعلام دائمًا موضوعي؟", options: ["نعم", "أحيانًا", "نادراً"], answer: "نادراً" },
        { question: "أكثر ما يؤثر على قراراتنا؟", options: ["العاطفة", "العقل", "البيئة"], answer: "العاطفة" },
        { question: "ما هو مفهوم الحرية؟", options: ["فعل ما تشاء", "أن تحترم الآخر", "أن لا تطيع أحداً"], answer: "أن تحترم الآخر" },
        { question: "لماذا تُهمّش بعض المناطق؟", options: ["بعيدة", "ضعف الإعلام", "تمييز مقصود"], answer: "تمييز مقصود" },
        { question: "كيف نكسر الصمت تجاه القضايا؟", options: ["بوست على فيسبوك", "نقاش مجتمعي عميق", "شكوى للمسؤول"], answer: "نقاش مجتمعي عميق" },
        { question: "ما هو الفرق بين الثورة والتمرد؟", options: ["الثورة هدفها بناء", "كلاهما عنف", "التمرد أناني"], answer: "الثورة هدفها بناء" },
        { question: "متى نصمت؟", options: ["عندما نخاف", "عندما نخطط", "عندما لا نعلم"], answer: "عندما لا نعلم" },
        { question: "من هو المواطن الواعي؟", options: ["الساكت", "المشارك", "المنفعل دائمًا"], answer: "المشارك" },
        { question: "هل كل صوت مرتفع يعني وعي؟", options: ["نعم", "لا", "أحيانًا"], answer: "لا" },
        { question: "متى تتحول حرية التعبير لفوضى؟", options: ["عندما تُستخدم للإساءة", "عندما تختلف الآراء", "عندما تكون عفوية"], answer: "عندما تُستخدم للإساءة" },
        { question: "ما أقرب طريق لفهم الواقع؟", options: ["الميديا", "التجربة", "الكتب فقط"], answer: "التجربة" },
        { question: "من الذي يصنع التاريخ؟", options: ["الأقوياء", "المثقفون", "الشعوب"], answer: "الشعوب" },
        { question: "هل السكوت على الظلم حياد؟", options: ["نعم", "لا", "حسب الموقف"], answer: "لا" },
        { question: "لماذا نُعيد أخطاء الماضي؟", options: ["نسيان الدروس", "الزمن يعيد نفسه", "لا نقرأ التاريخ"], answer: "لا نقرأ التاريخ" },
        { question: "أهم صفات الإنسان المتعلم؟", options: ["الغرور", "التواضع", "الحفظ فقط"], answer: "التواضع" },
        { question: "كيف نحارب الجهل؟", options: ["بالعقاب", "بالحوار", "بالهجرة"], answer: "بالحوار" },
        { question: "من أين يبدأ الإصلاح؟", options: ["من الحكومة", "من الإعلام", "من الذات"], answer: "من الذات" },
        { question: "ما علاقة الإبداع بالحرية؟", options: ["كلما زادت الحرية زاد الإبداع", "لا علاقة", "الإبداع ضد النظام"], answer: "كلما زادت الحرية زاد الإبداع" },
        { question: "هل يمكن أن نعيش بلا أمل؟", options: ["نعم", "لا", "ربما"], answer: "لا" },
        { question: "ما دور الفنان في الوعي؟", options: ["ترفيه فقط", "تحريك المشاعر", "تقليد الأجانب"], answer: "تحريك المشاعر" },
        { question: "ما قيمة الصدق في مجتمعات اليوم؟", options: ["لا قيمة", "ثروة نادرة", "شيء ثانوي"], answer: "ثروة نادرة" },
        { question: "كيف تعرف أنك حر؟", options: ["عندما تعارض بلا خوف", "عندما تسكت", "عندما تطيع فقط"], answer: "عندما تعارض بلا خوف" },
        { question: "هل كل متعلم واعٍ؟", options: ["نعم", "لا", "أحيانًا"], answer: "لا" },
        { question: "متى تكون الأسئلة أقوى من الأجوبة؟", options: ["عندما تحفّز التفكير", "عندما تضعف الثقة", "عندما تكون محرجة"], answer: "عندما تحفّز التفكير" }
    ];
    
    // أحداث النقر
    startQuizBtn.addEventListener('click', startGame);
    nextButton.addEventListener('click', () => {
        currentQuestionIndex++;
        setNextQuestion();
    });
    checkAnswerBtn.addEventListener('click', checkAnswer);
    restartButton.addEventListener('click', startGame);
    helpBtn.addEventListener('click', useHelp);
    callFriendBtn.addEventListener('click', callFriend);
    
    // بدء اللعبة
    function startGame() {
        welcomeScreen.classList.add('hide');
        quizScreen.classList.remove('hide');
        resultElement.classList.add('hide');
        
        shuffledQuestions = questions.sort(() => Math.random() - 0.5);
        currentQuestionIndex = 0;
        score = 0;
        helpUsed = false;
        callFriendUsed = false;
        
        helpBtn.disabled = false;
        callFriendBtn.disabled = false;
        
        setNextQuestion();
    }
    
    // عرض السؤال التالي
    function setNextQuestion() {
        resetState();
        showQuestion(shuffledQuestions[currentQuestionIndex]);
        startTimer();
    }
    
    // عرض السؤال
    function showQuestion(question) {
        questionElement.innerText = question.question;
        
        // خلط الإجابات عشوائيًا
        const shuffledOptions = question.options.sort(() => Math.random() - 0.5);
        
        shuffledOptions.forEach(option => {
            const button = document.createElement('button');
            button.innerText = option;
            button.classList.add('btn');
            if (option === question.answer) {
                button.dataset.correct = true;
            }
            button.addEventListener('click', selectAnswer);
            answerButtonsElement.appendChild(button);
        });
        
        checkAnswerBtn.classList.remove('hide');
        nextButton.classList.add('hide');
    }
    
    // إعادة تعيين الحالة
    function resetState() {
        clearInterval(timer);
        timeElement.innerText = questionTime;
        timeElement.classList.remove('timer-warning');
        
        while (answerButtonsElement.firstChild) {
            answerButtonsElement.removeChild(answerButtonsElement.firstChild);
        }
    }
    
    // بدء المؤقت
    function startTimer() {
        let timeLeft = questionTime;
        timeElement.innerText = timeLeft;
        
        timer = setInterval(() => {
            timeLeft--;
            timeElement.innerText = timeLeft;
            
            if (timeLeft <= 5) {
                timeElement.classList.add('timer-warning');
            }
            
            if (timeLeft <= 0) {
                clearInterval(timer);
                timeUp();
            }
        }, 1000);
    }
    
    // انتهاء الوقت
    function timeUp() {
        const buttons = answerButtonsElement.querySelectorAll('.btn');
        buttons.forEach(button => {
            button.disabled = true;
            if (button.dataset.correct === 'true') {
                button.classList.add('correct');
            }
        });
        
        checkAnswerBtn.classList.add('hide');
        nextButton.classList.remove('hide');
    }
    
    // اختيار الإجابة
    function selectAnswer(e) {
        const selectedButton = e.target;
        const buttons = answerButtonsElement.querySelectorAll('.btn');
        
        buttons.forEach(button => {
            button.disabled = true;
            button.classList.remove('selected');
        });
        
        selectedButton.classList.add('selected');
    }
    
    // التحقق من الإجابة
    function checkAnswer() {
        const selectedButton = answerButtonsElement.querySelector('.selected');
        
        if (!selectedButton) {
            alert('الرجاء اختيار إجابة قبل التحقق');
            return;
        }
        
        clearInterval(timer);
        
        const correct = selectedButton.dataset.correct === 'true';
        
        if (correct) {
            selectedButton.classList.add('correct');
            score++;
        } else {
            selectedButton.classList.add('wrong');
            // عرض الإجابة الصحيحة
            const buttons = answerButtonsElement.querySelectorAll('.btn');
            buttons.forEach(button => {
                if (button.dataset.correct === 'true') {
                    button.classList.add('correct');
                }
            });
        }
        
        checkAnswerBtn.classList.add('hide');
        
        if (shuffledQuestions.length > currentQuestionIndex + 1) {
            nextButton.classList.remove('hide');
        } else {
            setTimeout(endGame, 1500);
        }
    }
    
    // استخدام مساعدة (حذف إجابة خاطئة)
    function useHelp() {
        if (helpUsed) return;
        
        const buttons = Array.from(answerButtonsElement.querySelectorAll('.btn'));
        const wrongButtons = buttons.filter(button => button.dataset.correct !== 'true');
        
        if (wrongButtons.length > 1) {
            // حذف إجابة خاطئة عشوائية
            const randomIndex = Math.floor(Math.random() * wrongButtons.length);
            wrongButtons[randomIndex].classList.add('hide');
            helpUsed = true;
            helpBtn.disabled = true;
        }
    }
    
    // ميزة الاتصال بصديق
    function callFriend() {
        if (callFriendUsed) return;
        
        const buttons = Array.from(answerButtonsElement.querySelectorAll('.btn'));
        const correctButton = buttons.find(button => button.dataset.correct === 'true');
        
        if (correctButton) {
            // عرض رسالة محاكية لمساعدة الصديق
            alert(`صديقك يقول: أعتقد أن الإجابة الصحيحة هي "${correctButton.innerText}"`);
            callFriendUsed = true;
            callFriendBtn.disabled = true;
        }
    }
    
    // إنهاء اللعبة وعرض النتيجة
    function endGame() {
        quizScreen.classList.add('hide');
        resultElement.classList.remove('hide');
        scoreElement.innerText = score;
        totalElement.innerText = questions.length;
    }
});